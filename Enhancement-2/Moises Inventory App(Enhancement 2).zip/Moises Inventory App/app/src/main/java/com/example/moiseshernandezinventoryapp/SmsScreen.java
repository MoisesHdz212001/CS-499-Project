package com.example.moiseshernandezinventoryapp;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsScreen extends AppCompatActivity implements SensorEventListener {

    TextView statusText;          // Shows "Enabled" or "Disabled"
    TextView lightLevelText;      // Shows current light level
    EditText phoneNumberText;     // User enters phone number here

    private static final int SMS_PERMISSION_CODE = 1;

    private static final String PREFS_NAME = "smsPrefs";

    private static final String SMS_ENABLED_KEY = "smsEnabled";

    private static final String PHONE_NUMBER_KEY = "phoneNumber";

    private boolean smsEnabled = false;

    private SensorManager sensorManager;

    private Sensor lightSensor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_screen);

        statusText = findViewById(R.id.smsStatus);
        lightLevelText = findViewById(R.id.lightLevelText);
        phoneNumberText = findViewById(R.id.phoneNumberText);

        // This lets the app read light levels from the phone
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);

        // Load saved SMS setting and saved phone number from storage
        // SharedPreferences = simple way to store small data
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        smsEnabled = prefs.getBoolean(SMS_ENABLED_KEY, false);
        String savedPhoneNumber = prefs.getString(PHONE_NUMBER_KEY, "");

        // Put saved phone number back into the text box
        phoneNumberText.setText(savedPhoneNumber);

        // If permission was removed later, force SMS back to disabled
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            smsEnabled = false;
            saveSmsSetting(false);
        }

        updateStatusText();
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Start listening to the light sensor when screen is visible
        if (lightSensor != null) {
            sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();

        // Stop listening to sensor when leaving screen
        sensorManager.unregisterListener(this);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        // Show the current light level on screen
        float lightValue = event.values[0];
        lightLevelText.setText("Light Level: " + lightValue);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Not needed for this app
    }

    // This runs when the Enable SMS button is clicked
    public void enableSms(View view) {

        // Get phone number entered by user
        String phoneNumber = phoneNumberText.getText().toString().trim();

        // User has to enter a phone number
        if (phoneNumber.isEmpty()) {
            statusText.setText("Enter phone number first");
            return;
        }

        // Save the phone number entered
        savePhoneNumber(phoneNumber);

        // If SMS is already ON then turn it OFF
        if (smsEnabled) {
            smsEnabled = false;
            saveSmsSetting(false);
            updateStatusText();

            // Send disabled confirmation SMS
            sendSms(phoneNumber, "You have disabled SMS notifications for Moises Inventory App");
            return;
        }

        // If SMS is OFF then check permission first
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            // Ask the user for permission
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );

        } else {
            // Permission already granted then turn SMS ON
            smsEnabled = true;
            saveSmsSetting(true);
            updateStatusText();

            // Send enabled confirmation SMS
            sendSms(phoneNumber, "You have enabled SMS notifications for Moises Inventory App");
        }
    }

    // This runs after the user taps Allow or Deny on the permission popup
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            String phoneNumber = phoneNumberText.getText().toString().trim();

            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // User accepted permission then turn SMS ON
                smsEnabled = true;
                saveSmsSetting(true);
                updateStatusText();

                // Send confirmation message if phone number exists
                if (!phoneNumber.isEmpty()) {
                    savePhoneNumber(phoneNumber);
                    sendSms(phoneNumber, "You have enabled SMS notifications for Moises Inventory App");
                }

            } else {
                // User denied permission then keep SMS OFF
                smsEnabled = false;
                saveSmsSetting(false);
                updateStatusText();
            }
        }
    }

    // This updates the SMS Status on the screen
    private void updateStatusText() {
        if (smsEnabled) {
            statusText.setText("SMS Status: Enabled");
        } else {
            statusText.setText("SMS Status: Disabled");
        }
    }

    // This saves whether SMS is ON or OFF
    private void saveSmsSetting(boolean enabled) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean(SMS_ENABLED_KEY, enabled);
        editor.apply();
    }

    // This saves the user's phone number
    private void savePhoneNumber(String phoneNumber) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(PHONE_NUMBER_KEY, phoneNumber);
        editor.apply();
    }

    // This sends the SMS message
    private void sendSms(String number, String message) {

        // SmsManager is used to send text messages
        SmsManager smsManager = SmsManager.getDefault();

        // Send the message to the given number
        smsManager.sendTextMessage(number, null, message, null, null);
    }
}