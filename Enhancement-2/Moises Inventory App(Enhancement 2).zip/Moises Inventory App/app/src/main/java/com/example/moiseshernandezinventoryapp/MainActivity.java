package com.example.moiseshernandezinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText usernameText, passwordText;

    // This connects to InventoryDatabase
    InventoryDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        usernameText = findViewById(R.id.usernameText);
        passwordText = findViewById(R.id.passwordText);

        database = new InventoryDatabase(this);
    }

    // This runs when the Login button is clicked
    public void login(View view) {

        // Get the text the user typed into the input fields
        String username = usernameText.getText().toString();
        String password = passwordText.getText().toString();

        // Check if the username and password exist in the database
        if (database.checkUser(username, password)) {

            // If login is correct then go to the Home Inventory screen
            Intent intent = new Intent(this, HomeInventoryScreen.class);
            startActivity(intent);

        } else {

            // If login is incorrect then show an error message
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }
    }

    // This runs when Create Account button is clicked
    public void createAccount(View view) {

        // Go to the Create Account screen so the user can register
        Intent intent = new Intent(this, CreateAccountScreen.class);
        startActivity(intent);
    }
}