package com.example.moiseshernandezinventoryapp;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class InventoryDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory.db";

    // This is the version of the database
    // Increase this number when you change the database structure
    private static final int DATABASE_VERSION = 2;

    // Name of the table that stores login information
    public static final String TABLE_USERS = "users";

    // Column names for the users table
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Name of the table that stores inventory items
    public static final String TABLE_ITEMS = "items";

    // Column names for the items table
    public static final String COLUMN_ITEM_NAME = "name";
    public static final String COLUMN_ITEM_DESCRIPTION = "description";
    public static final String COLUMN_ITEM_QUANTITY = "quantity";

    // Constructor
    // This runs when another class creates InventoryDatabase
    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // This method runs ONLY the first time the database is created
    @Override
    public void onCreate(SQLiteDatabase db) {

        // Create the users table
        db.execSQL("CREATE TABLE " + TABLE_USERS +
                " (username TEXT, password TEXT)");

        // Create the items table
        db.execSQL("CREATE TABLE " + TABLE_ITEMS +
                " (name TEXT, description TEXT, quantity INTEGER)");
    }

    // This runs when the database version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        // Delete old tables
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ITEMS);

        onCreate(db);
    }

    // This method adds a new user
    public void addUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        // Put data into columns
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        // Insert the new user into the table
        db.insert(TABLE_USERS, null, values);

        db.close();
    }

    // This checks is a login check
    public boolean checkUser(String username, String password) {

        // Open database for reading
        SQLiteDatabase db = this.getReadableDatabase();

        // Query to find matching username and password
        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?", new String[]{username, password}
        );

        // If at least one row exists, user is valid
        boolean exists = cursor.getCount() > 0;

        cursor.close();
        db.close();

        return exists;
    }

    // This method adds a new item
    public void addItem(String name, String description, int quantity) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, name);
        values.put(COLUMN_ITEM_DESCRIPTION, description);
        values.put(COLUMN_ITEM_QUANTITY, quantity);

        // Insert new item into table
        db.insert(TABLE_ITEMS, null, values);

        db.close();
    }

    // This method deletes an item
    public void deleteItem(String name) {

        SQLiteDatabase db = this.getWritableDatabase();

        // Delete item where name matches
        db.delete(TABLE_ITEMS, COLUMN_ITEM_NAME + "=?", new String[]{name});

        db.close();
    }

    // This method updates an existing item
    public void updateItem(String originalName, String newName, String newDescription, int newQuantity) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(COLUMN_ITEM_NAME, newName);
        values.put(COLUMN_ITEM_DESCRIPTION, newDescription);
        values.put(COLUMN_ITEM_QUANTITY, newQuantity);

        // Update item where original name matches
        db.update(
                TABLE_ITEMS,
                values,
                COLUMN_ITEM_NAME + "=?",
                new String[]{originalName}
        );

        db.close();
    }

    // This method gets all items from the database
    public Cursor getAllItems() {

        SQLiteDatabase db = this.getReadableDatabase();

        // Return all rows from items table
        return db.rawQuery("SELECT * FROM " + TABLE_ITEMS, null);
    }
}