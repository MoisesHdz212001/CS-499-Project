package com.example.moiseshernandezinventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// This class displays inventory items in a scrolling list
public class DisplayInventoryList extends RecyclerView.Adapter<DisplayInventoryList.ItemViewHolder> {

    // Stores the inventory items
    private List<InventoryItem> items;

    // Gets the inventory items when the list is created
    public DisplayInventoryList(List<InventoryItem> items) {
        this.items = items;
    }

    // Creates a layout for each inventory item
    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);

        return new ItemViewHolder(view);
    }

    // Displays the name, description, and quantity
    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {

        InventoryItem item = items.get(position);

        holder.itemName.setText(item.name);
        holder.itemDescription.setText(item.description);
        holder.itemQuantity.setText("Quantity: " + item.quantity);

        // user opens the selected inventory item when clicked
        holder.itemView.setOnClickListener(v -> {
            int index = holder.getBindingAdapterPosition();

            if (index != RecyclerView.NO_POSITION) {
                ((HomeInventoryScreen) v.getContext()).openItem(index);
            }
        });
    }

    // Returns how many inventory items there are
    @Override
    public int getItemCount() {
        return items.size();
    }

    // Connects the Java code to the XML text fields
    public static class ItemViewHolder extends RecyclerView.ViewHolder {

        TextView itemName;
        TextView itemDescription;
        TextView itemQuantity;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemName);
            itemDescription = itemView.findViewById(R.id.itemDescription);
            itemQuantity = itemView.findViewById(R.id.itemQuantity);
        }
    }
}
