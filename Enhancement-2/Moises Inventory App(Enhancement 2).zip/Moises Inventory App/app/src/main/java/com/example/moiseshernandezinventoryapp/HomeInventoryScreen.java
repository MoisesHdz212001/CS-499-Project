package com.example.moiseshernandezinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import java.util.Collections;
import java.util.Comparator;

public class HomeInventoryScreen extends AppCompatActivity {

    // This connects InventoryDatabase
    InventoryDatabase database;

    // Scrolling list that displays inventory items
    RecyclerView inventoryRecyclerView;

    // Search bar used to find specific inventory items
    EditText searchInventory;

    // Stores the inventory items from the database
    ArrayList<InventoryItem> items;

    // Stores all inventory items before filtering
    ArrayList<InventoryItem> allItems;

    // Connects the inventory items to the scrolling list
    DisplayInventoryList inventoryListDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home_inventory_screen);

        // Create the database object so we can read items
        database = new InventoryDatabase(this);

        // Connect the scrolling list to the XML layout
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);

        // Connect the search bar to the XML layout
        searchInventory = findViewById(R.id.searchInventory);

        // Display inventory items in a vertical scrolling list
        inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create an empty list to store inventory items
        items = new ArrayList<>();

        // Create a list to keep all inventory items
        allItems = new ArrayList<>();

        // Connect the inventory items to the list display
        inventoryListDisplay = new DisplayInventoryList(items);
        inventoryRecyclerView.setAdapter(inventoryListDisplay);

        loadItems();

        // TextWatcher looks when the user types in the search bar
        searchInventory.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // Nothing needed here (Required by TextWatcher)
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Filter inventory items as the user is typing
                filterItems(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
                // Nothing needed here (Required by TextWatcher)
            }
        });
    }

    // This function gets all items from the database and displays them
    public void loadItems() {

        // Get all items from database
        // Cursor is like a list that lets us go through each row
        Cursor cursor = database.getAllItems();

        // Clear old items before loading updated inventory
        items.clear();

        // Clear the saved list before loading updated inventory
        allItems.clear();

        // Loop through every inventory item in the database
        while (cursor.moveToNext()) {

            String name = cursor.getString(0);
            String description = cursor.getString(1);
            int quantity = cursor.getInt(2);

            // Create an inventory item
            InventoryItem item = new InventoryItem(name, description, quantity);

            // Add the item to the displayed list and the complete inventory list
            items.add(item);
            allItems.add(item);

        }

        cursor.close();

        // Update scrolling list with the latest inventory items
        inventoryListDisplay.notifyDataSetChanged();
    }

    // Search inventory items by name
    public void filterItems(String searchText) {

        // Clear the displayed inventory list
        items.clear();

        // Check every item in the complete inventory list
        for (InventoryItem item : allItems) {

            // Check if the item name matches the search
            if (item.getName().toLowerCase().contains(searchText.toLowerCase())) {
                items.add(item);
            }
        }

        // Update the inventory display
        inventoryListDisplay.notifyDataSetChanged();
    }

    // Sort inventory items in alphabetical order
    public void sortItems(View view) {

        // Sort the complete inventory list from A to Z
        Collections.sort(allItems,
                Comparator.comparing(InventoryItem::getName,
                        String.CASE_INSENSITIVE_ORDER));

        // Update the displayed list while keeping the search filter
        filterItems(searchInventory.getText().toString());
    }

    // This opens the SMS Settings screen when the Settings button is clicked
    public void openSettings(View view) {
        Intent intent = new Intent(this, SmsScreen.class);
        startActivity(intent);
    }

    // This opens the Add Item screen when the "+ Add" button is clicked
    public void openAddItem(View view) {
        Intent intent = new Intent(this, AddItemScreen.class);
        startActivity(intent);
    }

    // This runs when returning to this screen
    // It reloads the items so any changes (add/update/delete) show immediately
    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    // This runs when a specific item box is clicked
    public void openItem(int index) {

        // Get the item selected from the displayed inventory list
        InventoryItem selectedItem = items.get(index);

        // Finds the position in the inventory list
        index = allItems.indexOf(selectedItem);

        // Gets all items from database again
        Cursor cursor = database.getAllItems();

        int currentIndex = 0;

        // Loop through items until we reach the one that was clicked
        while (cursor.moveToNext()) {

            if (currentIndex == index) {

                // Get item data
                String name = cursor.getString(0);
                String description = cursor.getString(1);
                int quantity = cursor.getInt(2);

                // Send this data to AddItemScreen
                Intent intent = new Intent(this, AddItemScreen.class);
                intent.putExtra("itemName", name);
                intent.putExtra("itemDescription", description);
                intent.putExtra("itemQuantity", quantity);

                // Open the Add/Edit screen
                startActivity(intent);

                cursor.close();
                return;
            }

            currentIndex++;
        }

        cursor.close();
    }
}