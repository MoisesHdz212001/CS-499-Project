package com.example.moiseshernandezinventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// This class controls the "Add Item" screen in the app
public class AddItemScreen extends AppCompatActivity {

    // Text box for item name
    EditText itemTitleText;

    // Text box for item description
    EditText itemDescriptionText;

    // Text for current quantity
    TextView quantityText;

    // Quantity of item
    int quantity = 1;

    // This connects to InventoryDatabase
    InventoryDatabase database;

    // This is used to check if we are editing an existing item
    // If this is null then we are adding a new item
    // If this has a value then we are editing an existing item
    String originalItemName = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_add_item);

        itemTitleText = findViewById(R.id.itemTitleText);
        itemDescriptionText = findViewById(R.id.itemDescriptionText);
        quantityText = findViewById(R.id.quantityText);

        // Create a connection to the database
        database = new InventoryDatabase(this);

        // Get data sent from the previous screen
        Intent intent = getIntent();

        // If data exists, it means we are editing an item
        if (intent.hasExtra("itemName")) {

            // Get item data from intent
            String name = intent.getStringExtra("itemName");
            String description = intent.getStringExtra("itemDescription");
            int savedQuantity = intent.getIntExtra("itemQuantity", 1);

            // Store original name so we can update/delete later
            originalItemName = name;

            // Fill the screen with existing item data
            itemTitleText.setText(name);
            itemDescriptionText.setText(description);

            // Set quantity
            quantity = savedQuantity;
            quantityText.setText("Qty: " + quantity);
        }
    }

    // This runs when the "+" button is pressed
    public void increaseQuantity(View view) {

        // Increase quantity by 1
        quantity++;

        // Update the text on screen
        quantityText.setText("Qty: " + quantity);
    }

    // This runs when the "-" button is pressed
    public void decreaseQuantity(View view) {

        // Avoids quantity from going below 1
        if (quantity > 1) {
            quantity--;

            // Update the text on screen
            quantityText.setText("Qty: " + quantity);
        }
    }

    // This runs when the "Save Item" button is pressed
    public void saveItem(View view) {

        // Get what the user typed
        String name = itemTitleText.getText().toString();
        String description = itemDescriptionText.getText().toString();

        // Check if user is editing or adding
        if (originalItemName != null) {

            // Editing existing item
            database.updateItem(originalItemName, name, description, quantity);

        } else {

            // Adding a new item
            database.addItem(name, description, quantity);
        }

        // Show saved confirmation message
        Toast.makeText(this, "Item saved", Toast.LENGTH_SHORT).show();

        finish();
    }

    // This runs when the "Delete Item" button is pressed
    public void deleteItem(View view) {

        // Only delete if user is editing an existing item
        if (originalItemName != null) {

            // Remove item from database
            database.deleteItem(originalItemName);

            // Show deleted confirmation message
            Toast.makeText(this, "Item deleted", Toast.LENGTH_SHORT).show();

            finish();
        }
    }

    // This runs when the "Home" button is pressed
    public void goHome(View view) {

        // Go to HomeInventoryScreen
        Intent intent = new Intent(this, HomeInventoryScreen.class);
        startActivity(intent);
    }

    // This runs when the "Sign Out" button is pressed
    public void signOut(View view) {

        // Go to login screen
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}