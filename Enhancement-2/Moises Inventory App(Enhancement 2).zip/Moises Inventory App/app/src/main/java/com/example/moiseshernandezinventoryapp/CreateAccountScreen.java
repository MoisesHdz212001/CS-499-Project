package com.example.moiseshernandezinventoryapp;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class CreateAccountScreen extends AppCompatActivity {

    // Where user types their new username
    EditText newUsernameText;

    // Where user types their new password
    EditText newPasswordText;

    // This connects to InventoryDatabase
    InventoryDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_create_account_screen);

        newUsernameText = findViewById(R.id.newUsernameText);
        newPasswordText = findViewById(R.id.newPasswordText);

        database = new InventoryDatabase(this);
    }

    // This runs when the "Save Account" button is clicked
    public void saveAccount(View view) {

        // Get the text the user typed into the input fields
        String username = newUsernameText.getText().toString();
        String password = newPasswordText.getText().toString();

        // This adds a new user into the database
        database.addUser(username, password);

        // Show a short message to confirm the account was created
        Toast.makeText(this, "Account created", Toast.LENGTH_SHORT).show();

        finish();
    }
}