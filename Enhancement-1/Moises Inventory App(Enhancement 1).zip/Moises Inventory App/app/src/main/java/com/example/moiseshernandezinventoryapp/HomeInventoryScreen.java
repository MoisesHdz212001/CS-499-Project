package com.example.moiseshernandezinventoryapp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class HomeInventoryScreen extends AppCompatActivity {

    // This connects InventoryDatabase
    InventoryDatabase database;

    // Scrolling list that displays inventory items
    RecyclerView inventoryRecyclerView;

    // Stores the inventory items from the database
    ArrayList<InventoryItem> items;

    // Connects the inventory items to the scrolling list
    DisplayInventoryList inventoryListDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_home_inventory_screen);

        // Create the database object so we can read items
        database = new InventoryDatabase(this);

        // Connect the scrolling list to the XML layout
        inventoryRecyclerView = findViewById(R.id.inventoryRecyclerView);

        // Display inventory items in a vertical scrolling list
        inventoryRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create an empty list to store inventory items
        items = new ArrayList<>();

        // Connect the inventory items to the list display
        inventoryListDisplay = new DisplayInventoryList(items);
        inventoryRecyclerView.setAdapter(inventoryListDisplay);

        loadItems();
    }

    // This function gets all items from the database and displays them
    public void loadItems() {

        // Get all items from database
        // Cursor is like a list that lets us go through each row
        Cursor cursor = database.getAllItems();

        // Clear old items before loading updated inventory
        items.clear();

        // Loop through every inventory item in the database
        while (cursor.moveToNext()) {

            String name = cursor.getString(0);
            String description = cursor.getString(1);
            int quantity = cursor.getInt(2);

            // Add inventory item to the scrolling list
            items.add(new InventoryItem(name, description, quantity));

        }

        cursor.close();

        // Update scrolling list with the latest inventory items
        inventoryListDisplay.notifyDataSetChanged();
    }

    // This opens the SMS Settings screen when the Settings button is clicked
    public void openSettings(View view) {
        Intent intent = new Intent(this, SmsScreen.class);
        startActivity(intent);
    }

    // This opens the Add Item screen when the "+ Add" button is clicked
    public void openAddItem(View view) {
        Intent intent = new Intent(this, AddItemScreen.class);
        startActivity(intent);
    }

    // This runs when returning to this screen
    // It reloads the items so any changes (add/update/delete) show immediately
    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    // This runs when a specific item box is clicked
    public void openItem(int index) {

        // Get all items from database again
        Cursor cursor = database.getAllItems();

        int currentIndex = 0;

        // Loop through items until we reach the one that was clicked
        while (cursor.moveToNext()) {

            if (currentIndex == index) {

                // Get item data
                String name = cursor.getString(0);
                String description = cursor.getString(1);
                int quantity = cursor.getInt(2);

                // Send this data to AddItemScreen
                Intent intent = new Intent(this, AddItemScreen.class);
                intent.putExtra("itemName", name);
                intent.putExtra("itemDescription", description);
                intent.putExtra("itemQuantity", quantity);

                // Open the Add/Edit screen
                startActivity(intent);

                cursor.close();
                return;
            }

            currentIndex++;
        }

        cursor.close();
    }
}