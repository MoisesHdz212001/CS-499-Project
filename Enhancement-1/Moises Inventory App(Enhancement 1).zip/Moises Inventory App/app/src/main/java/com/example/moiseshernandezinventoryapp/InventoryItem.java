
package com.example.moiseshernandezinventoryapp;

public class InventoryItem {

    // Name, Description, and quantity about an inventory item
    String name;
    String description;
    int quantity;

    // Creates the inventory item
    public InventoryItem(String name, String description, int quantity) {
        this.name = name;
        this.description = description;
        this.quantity = quantity;
    }
}
